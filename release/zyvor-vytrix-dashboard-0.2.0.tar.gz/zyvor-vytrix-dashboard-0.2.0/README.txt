Zyvor Vytrix dashboard 0.2.0 — built Cloudflare Worker (dist/server) and static assets (dist/client).

Deploy to Cloudflare:   npx wrangler@4 deploy --config dist/server/wrangler.json
Serve locally:          npx wrangler@4 dev --config dist/server/wrangler.json --local --ip 127.0.0.1 --port 8787

Then point the collector at it with --ui-upstream http://127.0.0.1:8787, or connect from the dashboard.
https://github.com/zyvorai/zyvor-vytrix
